import datetime
import json
import hmac
import hashlib
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import requests
from rest_framework.response import Response
from django.contrib.auth.decorators import login_required, user_passes_test
from programs.models import Classroom
from .forms import SignupForm, StudentProfileForm, TeacherProfileForm, AvatarUpload, ProfileForm
from django.db.models import Sum
from django.core.paginator import Paginator
from .models import CustomUser, Profile
from core.slack_utils import send_slack_notification
from points.models import Points
from news.models import Announcement

# Login View

def user_login(request):
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the username exists
        try:
            user = CustomUser.objects.get(username=username)
        except CustomUser.DoesNotExist:
            messages.error(request, 'Invalid username.')
            return render(request, 'login.html', {'form': form})

        # Check if the account is pending approval
        if not user.is_approved:
            messages.error(request, 'Your account is pending approval.')
            return render(request, 'login.html', {'form': form})

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('core:home')
        else:
            messages.error(request, 'Invalid password.')
            return render(request, 'login.html', {'form': form})

    return render(request, 'login.html', {'form': form})

# Logout View
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('core:home')


# Signup View
def signup_view(request):
    form = SignupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save(commit=False)
        user.set_password(form.cleaned_data['password1'])
        user.is_active = False  # User must be approved first
        user.save()
        send_slack_notification('new_signup', user.username, 'approval_needed')
        messages.success(request, 'Account created! Please wait for approval.')
        return redirect('user_login')

    return render(request, 'signup.html', {'form': form})

@login_required
def profile_view(request):
    profile = request.user.profile
    return render(request, 'profile.html')

@login_required
def edit_profile(request):
    profile = request.user.profile

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.generate_avatar()  # Generate the avatar
            profile.save()
            return redirect('profile')
    else:
        form = ProfileForm(instance=profile)

    return render(request, 'edit_profile.html', {'form': form})

@login_required
def complete_profile(request):
    user = request.user

    # If profile is already completed, redirect to the appropriate dashboard
    if user.profile_completed:
        if user.role == 'student':
            return redirect('student_dashboard')  # Redirect to student dashboard
        elif user.role == 'teacher':
            return redirect('teacher_dashboard')  # Redirect to teacher dashboard

    if request.method == 'POST':
        if user.role == 'student':
            form = StudentProfileForm(request.POST, instance=user.profile)
        else:
            form = TeacherProfileForm(request.POST, instance=user.profile)

        if form.is_valid():
            profile = form.save()
            if user.role == 'student':
                user.level = form.cleaned_data['level']
            user.profile_completed = True
            user.save()

            # Redirect to the appropriate dashboard
            if user.role == 'student':
                return redirect('student_dashboard')
            elif user.role == 'teacher':
                return redirect('teacher_dashboard')

    else:
        if user.role == 'student':
            form = StudentProfileForm(instance=user.profile)
        else:
            form = TeacherProfileForm(instance=user.profile)

    return render(request, 'complete_profile.html', {'form': form})

# Teacher Dashboard View
@login_required
@user_passes_test(lambda user: user.role == 'teacher', login_url='home')
def teacher_dashboard(request):
    # Check if profile is complete
    if not request.user.profile.first_name or not request.user.profile.last_name or not request.user.profile.teaching_place:
        return redirect('complete_profile')

    # Fetch announcements with pagination
    announcements = Announcement.objects.all().order_by('-created_at')
    paginator = Paginator(announcements, 5)  # Show 5 announcements per page
    page_number = request.GET.get('page')
    announcements_page = paginator.get_page(page_number)

    classrooms = Classroom.objects.filter(teacher=request.user)

    # Avatar Upload Handling
    profile = request.user.profile
    if request.method == 'POST':
        form = AvatarUpload(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('teacher_dashboard')  # Refresh page after saving
    else:
        form = AvatarUpload(instance=profile)

    context = {
        'announcements': announcements_page,
        'classrooms': classrooms,
        'profile': profile,
        'role': request.user.role,
        'form': form,  # Include the form in context
    }
    return render(request, 'teacher_dashboard.html', context)


# Student Dashboard View
@login_required
@user_passes_test(lambda user: user.role == 'student', login_url='home')
def student_dashboard(request):
    # Check if profile is complete
    if not request.user.profile.first_name or not request.user.profile.last_name or not request.user.profile.school or not request.user.profile.age:
        return redirect('complete_profile')

    teams = getattr(request.user, 'team', None)  # Assuming ManyToOne relationship
    points = Points.objects.filter(user=request.user).aggregate(total=Sum('points_earned'))['total'] or 0
    classes = request.user.classrooms.filter(date__gte=datetime.date.today())

    # Avatar Upload Handling
    profile = request.user.profile
    if request.method == 'POST':
        form = AvatarUpload(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('student_dashboard')  # Refresh page after saving
    else:
        form = AvatarUpload(instance=profile)

    context = {
        'teams': teams,
        'points': int(points),
        'classes': classes,
        'profile': profile,
        'role': request.user.role,
        'form': form,  # Include the form in context
    }
    return render(request, 'student_dashboard.html', context)


# Approve User View
@login_required
@user_passes_test(lambda user: user.is_staff, login_url='home')
def approve_user(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)
    if request.method == 'POST':
        user.is_approved = True
        user.is_active = True
        user.save()
        send_slack_notification('approval', user.username, 'account_approved')
        messages.success(request, f"User {user.username} approved.")
        return redirect('admin_dashboard')

    return render(request, 'approve_user.html', {'user': user})


# Create Announcement View
@login_required
@user_passes_test(lambda user: user.role == 'teacher', login_url='home')
def create_announcement(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        announcement = Announcement.objects.create(
            title=title,
            content=content,
            created_at=datetime.now(),
        )
        messages.success(request, "Announcement created successfully!")
        return redirect('teacher_dashboard')

    return render(request, 'news/create_announcement.html')


@login_required
def upload_avatar(request):
    """
    Handles avatar upload for a user.
    """
    profile = request.user.profile  # Ensure we get the user's profile
    if request.method == "POST":
        form = AvatarUpload(request.POST, request.FILES, instance=profile)  # Correct instance
        if form.is_valid():
            form.save()
            return redirect('users:profile_view')  # Redirect to profile page
    else:
        form = AvatarUpload(instance=profile)

    return render(request, 'users/upload_avatar.html', {'form': form})  # Corrected path


@login_required
def avatar_management(request):
    """
    Handles avatar management (upload & view).
    """
    profile = request.user.profile
    if request.method == 'POST':
        form = AvatarUpload(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('users:profile_view')  # Redirect to profile after saving
    else:
        form = AvatarUpload(instance=profile)

    return render(request, 'users/avatar_management.html', {'form': form, 'profile': profile})  # Corrected path

@login_required
def generate_avatar(request):
    profile = request.user.profile

    # Generate the avatar and save it
    profile.generate_avatar()

    # Redirect back to profile or avatar management page
    return redirect('avatar_management')






