from django.urls import path
from . import views

app_name = "users"

urlpatterns = [
    path('login/', views.user_login, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup/', views.signup_view, name='signup'),
    path('profile/', views.profile_view, name = 'profile'),
    path('edit_profile', views.edit_profile, name = 'edit_profile'),
    path('complete_profile/', views.complete_profile, name='complete_profile'),

    # Dashboards
    path('teacher_dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('student_dashboard/', views.student_dashboard, name='student_dashboard'),

    # Classroom & Announcements
    path('create_announcement/', views.create_announcement, name='create_announcement'),

    # Avatar Management
    path('manage-avatar/', views.avatar_management, name='avatar_management'),
    path('generate-avatar/', views.generate_avatar, name='generate_avatar'),
    path('upload-avatar/', views.upload_avatar, name='upload_avatar'),
]
