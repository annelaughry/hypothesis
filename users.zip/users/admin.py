from django.contrib import admin
from .models import Profile, CustomUser


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'first_name', 'last_name', 'points', 'school', 'teaching_place')
    list_filter = ('school', 'teaching_place')
    search_fields = ('user__username', 'first_name', 'last_name')
    ordering = ('user__username',)
    list_per_page = 50
    readonly_fields = ('created_at', 'updated_at')

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_active', 'is_staff', 'is_approved', 'role', 'date_joined')
    list_filter = ('is_active', 'is_staff', 'is_approved','role', 'date_joined')
    search_fields = ('username', 'email')
    ordering = ('username',)
    list_per_page = 50
    readonly_fields = ('date_joined', 'last_login')
    fieldsets = (
        (None, {'fields': ('username', 'email', 'password')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_approved', 'role')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
