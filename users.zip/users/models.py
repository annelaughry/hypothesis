from django.db import models
from django.contrib.auth.models import AbstractUser, Group
from django.db.models.signals import post_save, post_migrate
from django.dispatch import receiver
from django.core.exceptions import ValidationError
from django.contrib import admin
from python_avatars import Avatar 
from pippet_project import settings
from django.core.files.base import ContentFile
import io
import python_avatars
# Create your models here.

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('teacher', 'Teacher'),
        ('student', 'Student'),
    ]
    LEVEL_CHOICES = [
        ('explorer', 'Explorer'),
        ('ambassador', 'Ambassador'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, blank=True, null=True) #only for students
    is_approved = models.BooleanField(default=False)
    profile_completed = models.BooleanField(default=False) #new field to track completions

    def __str__(self):
        return f"{self.username} ({self.role})"

    def is_admin(self):
        return self.role == 'admin'

    def is_teacher(self):
        return self.role == 'teacher'

    def is_student(self):
        return self.role == 'student'

class Profile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='profile')
    points = models.PositiveIntegerField(default=0)

    # User Information
    first_name = models.CharField(max_length=50, blank=True, null=True)
    last_name = models.CharField(max_length=50, blank=True, null=True)
    school = models.CharField(max_length=100, blank=True, null=True)  
    age = models.PositiveIntegerField(blank=True, null=True)  
    teaching_place = models.CharField(max_length=100, blank=True, null=True)  

    # Avatar Fields
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    
    # Change this field to store an actual image instead of text
    generated_avatar = models.ImageField(upload_to='avatars/generated/', blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def generate_avatar(self):
        """Generate a random avatar using python-avatars and save it as an image."""
        avatar_image = python_avatars.Avatar.random().render_png()

        # Save the avatar as an image file
        avatar_io = io.BytesIO()
        avatar_image.save(avatar_io, format='PNG')
        avatar_io.seek(0)

        # Save the generated avatar into the ImageField
        self.generated_avatar.save(f'{self.user.username}_avatar.png', ContentFile(avatar_io.read()), save=True)

    def has_avatar(self):
        return self.avatar or self.generated_avatar

    def __str__(self):
        return f"Profile of {self.user.username}"

    def update_points(self):
        """Recalculates and updates the total points for the user."""
        total_points = self.user.points_set.aggregate(total=models.Sum('points_earned'))['total'] or 0
        self.points = total_points
        self.save()


@receiver(post_save, sender=CustomUser)
def create_or_update_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    else:
        instance.profile.save()

@receiver(post_migrate)
def create_groups(sender, **kwargs):
    Group.objects.get_or_create(name='Admin')
    Group.objects.get_or_create(name='Teacher')
    Group.objects.get_or_create(name='Student')

