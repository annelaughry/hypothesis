from django import forms
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django.core.validators import EmailValidator, validate_email
from django.contrib.auth.password_validation import (
    validate_password, 
    UserAttributeSimilarityValidator,
    CommonPasswordValidator,
    NumericPasswordValidator
)
from .models import CustomUser, Profile

class SignupForm(UserCreationForm):
    email = forms.EmailField(
        validators=[validate_email], 
        help_text="Enter a valid email address"
    )
    
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'role', 'level', 'password1', 'password2']
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if CustomUser.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already taken.")
        return username
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email=email).exists():
            raise forms.ValidationError("Email already registered.")
        return email
    
    def clean_password2(self):
        password1 = self.cleaned_data.get('password1')
        password2 = self.cleaned_data.get('password2')
        
        # Built-in Django password validators
        validate_password(password1, self.instance)
        
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Passwords don't match.")
        
        return password2

class StrongPasswordChangeForm(PasswordChangeForm):
    def clean_new_password2(self):
        password1 = self.cleaned_data.get('new_password1')
        password2 = self.cleaned_data.get('new_password2')
        
        # Additional custom password validation
        if len(password1) < 12:
            raise forms.ValidationError("Password must be at least 12 characters long.")
        
        validate_password(password1, self.user)
        
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("New passwords don't match.")
        
        return password2

# Rest of your forms remain the same
class StudentProfileForm(forms.ModelForm):
    # Existing implementation
    pass

class TeacherProfileForm(forms.ModelForm):
    # Existing implementation
    pass

class AvatarUpload(forms.ModelForm):
    # Existing implementation
    pass


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = [
            'first_name',
            'last_name',
            'school',
            'age',
            'teaching_place',
            'avatar',
            'generated_avatar'
        ]
        
        widgets = {
            'avatar': forms.ClearableFileInput(),  # To support avatar upload
        }