from django.contrib.auth.models import Group
from django.db.models.signals import post_save
from django.dispatch import receiver
from users.models import CustomUser, Profile
import logging

logger = logging.getLogger(__name__)

@receiver(post_save, sender=CustomUser)
def handle_user_creation(sender, instance, created, **kwargs):
   if created:
       # Assign group
       try:
           group_name = 'Students' if instance.role == 'student' else 'Teachers'
           group, _ = Group.objects.get_or_create(name=group_name)
           instance.groups.add(group)
       except Exception as e:
           logger.error(f"Group assignment error for {instance.username}: {e}")
       
       # Create profile
       try:
           Profile.objects.create(user=instance)
       except Exception as e:
           logger.error(f"Profile creation error for {instance.username}: {e}")

@receiver(post_save, sender=CustomUser)
def update_profile(sender, instance, **kwargs):
   try:
       if hasattr(instance, 'profile'):
           instance.profile.save()
   except Exception as e:
       logger.warning(f"Profile save error for {instance.username}: {e}")